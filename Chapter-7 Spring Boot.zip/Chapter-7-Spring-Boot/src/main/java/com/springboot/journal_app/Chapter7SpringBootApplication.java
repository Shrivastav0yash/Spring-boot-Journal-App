package com.springboot.journal_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter7SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter7SpringBootApplication.class, args);
	}

}
