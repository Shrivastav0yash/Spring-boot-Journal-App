package com.springboot.journal_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter7SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
